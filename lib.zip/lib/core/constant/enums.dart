enum Status { initial, loading, success, error }
