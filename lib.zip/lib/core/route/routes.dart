class Routes {
  static const String login = '/login';
  static const String signup = '/signup';
  static const String signupmore = '/signupmore';
  static const String signuplast = '/signuplast';
  static const String starter = '/starter';
  static const String home = '/home';
  static const String product = '/product';
  static const String productdetail = '/productdetail';
}
